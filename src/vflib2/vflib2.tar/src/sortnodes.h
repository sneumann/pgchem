/*----------------------------------------------------
 * sortnodes.h
 * Header of sortnodes.cc
 *--------------------------------------------------*/

#ifndef SORTNODES_H
#define SORTNODES_H

#include "argraph.h"

node_id* SortNodesByFrequency(Graph *g);

#endif
